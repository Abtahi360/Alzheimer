# Explainable Federated Deep Learning for Alzheimer's Disease Detection

Springer Nature manuscript, single-file LaTeX source. Builds as supplied: 32 pages,
no errors, no undefined references, 59 bibliography entries.

## Build

```
make          # pdflatex, bibtex, pdflatex, pdflatex
make clean    # remove auxiliary files
```

Nothing to install beyond a standard TeX Live distribution.

## Layout

```
sn-article.tex     every section, abstract through conclusion, in one file
refs.bib           40 domain references + 19 verified methodological references
images/            all seven result figures
sn-jnl.cls         Springer Nature class
sn-*.bst           bibliography styles
Makefile
```

Section start pages: Introduction 2, Related Work 3 (Table 1 on page 6),
Methods 5, Results 13, Discussion 23, Conclusion 26, References 27.

Figure 1 is drawn in TikZ inside `sn-article.tex` and needs no image file. The other
seven figures are in `images/`:

| File | Figure |
|---|---|
| `fig_auc_f1.png` | Fig. 2, AUC and F1 across models and test sets |
| `fig_cm_internal.jpeg` | Fig. 3, internal confusion matrices |
| `fig_int_vs_ext.png` | Fig. 4, internal against external |
| `fig_domain_shift.png` | Fig. 5, pixel-intensity distributions |
| `fig_cm_external.jpeg` | Fig. 6, external confusion matrices |
| `fig_xai_gradcam_lime.png` | Fig. 7, Grad-CAM++ and LIME |
| `fig_xai_scorecam_occ_rollout.png` | Fig. 8, Score-CAM, occlusion, rollout |

## Class files

`sn-jnl.cls` and the `.bst` files came from a public mirror so the project builds out of
the box. They are not mine to distribute and may not be the current release. Before
submitting, download the official bundle from the journal's author page and overwrite
them. If you do, note that recent bundles rename the numbered mathematics and physical
sciences style to `sn-mathphys-num.bst` and expose it as a class option; in that case set

```
\documentclass[pdflatex,sn-mathphys-num]{sn-jnl}
```

and drop the `Numbered` option, which the newer class does not use.

## Reference style

Numbered citations, via `[pdflatex,sn-mathphys,Numbered]`. The prose is written for
numeric style, as in "Gao and Lima [1] presented a review". Switching to author-year
would require changing every `\cite{}` to `\citep{}` and removing the author names
already in the sentences.

## One figure caption needs your attention

`fig_domain_shift.png` has a legend reading "OASIS" and "External", where "External" is
your code's name for the Kaggle **training** cohort. In the paper, "external" means OASIS,
so the labels are the reverse of what a reader will assume. The caption for Figure 5 says
this explicitly, but relabelling the figure to "Training cohort" and "External test
(OASIS)" would be cleaner. Regenerating it would also let you drop that sentence.

## Open items

Front-matter fields marked `%% VERIFY` in `sn-article.tex`: author block,
acknowledgements, data availability, code availability, author contributions.

Two substantive items.

1. **Federated client construction.** How many clients, and the rule used to partition the
   4,489 training images. Part 3 loads the federated checkpoints rather than creating them,
   so this is not recoverable from the code supplied. The Methods says only that clients
   were formed by partitioning the training partition.

2. **Which run is definitive.** Six figures differ between your recorded results and the
   Part 3 notebook output. The manuscript uses the recorded results.

   | Quantity | Used | Part 3 notebook |
   |---|---|---|
   | KS statistic, pixel mean | 0.957 | 0.9667 |
   | KS statistic, pixel SD | 0.993 | 0.9967 |
   | MMD | 0.517 | 0.5344 |
   | Mean pixel intensity, OASIS | 42.66 | 41.14 |
   | Latency, centralized | 48.68 ms | 52.38 ms |
   | Latency, FedAvg / FedProx / FedBN | 46.52 / 45.80 / 46.54 ms | 54.82 / 57.28 / 55.44 ms |

   Everything else matches exactly: all accuracy, AUC and F1 values, the Optuna
   configuration, parameter counts and communication cost.

## Outputs that must not be reported

Three results in the Part 3 notebook are explicitly synthetic and would be fabricated
evidence if published. None appear in this manuscript.

- **Sex and age fairness** (cell 55, sections C and D), labelled in your code as
  "simulated -- replace with OASIS demog CSV". Group membership is assigned arbitrarily.
- **Cohen's kappa for expert agreement** (cell 72), labelled "Simulated below -- replace
  with real expert ratings". The reported 0.6269 is not a measurement.
- **ComBat-style harmonisation** (cell 15) processed one site against itself, giving
  offset 0.00 and scale 1.000. It was a no-op.

Per-stage and per-site fairness (cell 55, sections A, B, F) are real, as are the PCA
variance figures, PC1 = 57.5 percent and PC2 = 8.0 percent. These could be added.

## Analyses deliberately absent from the Methods

The Methods describe only analyses that produced reported results. Monte Carlo dropout,
the 13-variant ablation, the CNN-LSTM and backbone baselines, subgroup and fairness
analysis, t-SNE and UMAP, SHAP, and the Wilcoxon and paired t-tests exist in the code but
produced no verified output. Describing them would invite a reviewer to ask where the
results are. They are listed as gaps in Section 5.5.

## Reference notes

Score-CAM is paginated 111-119 in IEEE Xplore and 24-25 in the CVF repository; the bib
uses the IEEE pagination and records the alternative in a comment. The Grad-CAM++ first
author is indexed "Chattopadhay" in the WACV proceedings and "Chattopadhyay" elsewhere;
the bib uses the proceedings spelling.
